import React from 'react';

const Alldata = 
[
    {
        imgsrc : "https://images.pexels.com/photos/205740/pexels-photo-205740.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        alt:"xuv",
        width : "300px",
        height : "300px",
        title : "Mahindra XUV 300",
        price : "10000",
        link : "abcd"
    },
    
    {
        imgsrc : "https://images.pexels.com/photos/4083525/pexels-photo-4083525.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        alt:"jaguar",
        width : "300px",
        height : "300px",
        title : "JAGUAR 99",
        price : "450000",
        link : "#"
    },
    
    {
        imgsrc : "https://images.pexels.com/photos/4055176/pexels-photo-4055176.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        alt:"hummar",
        width : "300px",
        height : "300px",
        title : "Hummar 3xx",
        price : "900000",
        link : "#"
    },
    
    {
        imgsrc : "https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?cs=srgb&dl=pexels-mike-116675.jpg&fm=jpg",
        alt:"Thar",
        width : "300px",
        height : "300px",
        title : "Mahindra Thar 7D",
        price : "112000",
        link : "#"
    }
    
]

export default Alldata;


